'''
2023年5月28日  屈雯静
瘦脸功能：可以对图片和实时视频通过参数控制实现不同程度的瘦脸功能
'''

import math
import cv2
import imutils
import numpy as np
import dlib


def get_face_key_point_710(img_src, detector, predictor):
    # 将图像转换为灰度图
    # 转灰度时图片要为三通道
    img_gray = cv2.cvtColor(img_src, cv2.COLOR_BGR2GRAY)

    # 存储检测到的人脸关键点
    store_key = []

    # 在灰度框中检测人脸，得到人脸检测矩形框4点坐标
    rects = detector(img_gray, 0)

    # 遍历每一个检测到的人脸
    for i in range(len(rects)):
        # 获取当前人脸的关键点
        # np.matrix:返回矩阵
        land_marks_node = np.matrix([[p.x, p.y] for p in predictor(img_gray, rects[i]).parts()])
        # 将关键点存储在结果中
        store_key.append(land_marks_node)

    return store_key

# 变化前u附近的值求出u的像素值
def BilinearInsert_710(ori_img, ux, uy):
    # 双线性插值法
    w, h, c = ori_img.shape

    if c == 3:
        # 通道数为3，是彩色图像
        x1 = int(ux)
        x2 = x1+1
        y1 = int(uy)
        y2 = y1+1

        # 计算插值的四个部分
        # part1,= f(y)
        part1 = ori_img[y1, x1].astype(float)*(float(x2)-ux)*(float(y2)-uy)
        part2 = ori_img[y1, x2].astype(float)*(ux-float(x1))*(float(y2)-uy)
        part3 = ori_img[y2, x1].astype(float)*(float(x2) - ux)*(uy-float(y1))
        part4 = ori_img[y2, x2].astype(float)*(ux-float(x1))*(uy - float(y1))

        # 得到插值结果
        insertValue = part1+part2+part3+part4

        return insertValue.astype(np.int8)

# 利用局部平移算法实现瘦脸效果
# 公式的c,m的坐标  m:鼻尖坐标end   r:瘦脸的距离 c:脸的点start
def part_translate_710(origin_img, start_x, start_y, end_x, end_y, radius):

    r_2 = float(radius * radius)
    resu_image = origin_img.copy()

    # 计算公式中的|m-c|^2
    ddmc = math.pow((end_x - start_x), 2) + math.pow((end_y - start_y), 2)
    H, W, C = origin_img.shape

    for i in range(W):
        for j in range(H):
            # 该点是否在矩形范围内
            # 以c为中心的2r * 2r的矩阵，矩形里有内切圆
            if math.fabs(i-start_x) > radius and math.fabs(j-start_y) > radius:
                continue

            # |x-c|^2
            distance = math.pow((i - start_x), 2) + math.pow((j - start_y), 2)

            # 该点是否在形变圆内
            if(distance < r_2):
                # 计算公式中右边平方里的部分
                ratio = (r_2-distance) / (r_2 - distance + ddmc)
                ratio = math.pow(ratio, 2)

                # 映射原位置
                # 计算x点（i,j）的原坐标u
                ux = i - ratio * (end_x - start_x)  # m-c=end_x - start_x
                uy = j - ratio * (end_y - start_y)

                # 根据双线性插值法得到UX，UY的像素值
                value = BilinearInsert_710(origin_img, ux, uy)
                # 改变当前 i ，j的值
                resu_image[j, i] = value

    return resu_image

def core_face_li_710(image, detector, predictor, degree):

    if degree < 25:
        i = 0
    elif 25 <= degree < 50:
        i = 1
    elif 50 <= degree < 75:
        i = 2
    elif 75 <= degree <= 100:
        i = 3

    parm1 = [2, 3, 1, 3]
    parm2 = [3, 4, 2, 5]
    parm3 = [12, 12, 10, 13]
    parm4 = [13, 14, 12, 15]


    # 获得多个人脸的关键点
    landmarks = get_face_key_point_710(image, detector, predictor)

    # 如果未检测到人脸关键点，就不进行瘦脸功能
    if len(landmarks) == 0:
        return image

    # 遍历每一个人脸关键点
    for landmarks_node in landmarks:
        # 获取左脸的两个关键点
        left_face_p1 = landmarks_node[parm1[i]]
        left_face_p2 = landmarks_node[parm2[i]]

        # 获取右脸的两个关键点
        right_face_p1 = landmarks_node[parm3[i]]
        right_face_p2 = landmarks_node[parm4[i]]

        # 获取鼻尖的关键点，第31个点
        nose_p = landmarks_node[30]

        # 计算两个的距离作为瘦脸距离
        # √ ((x1-x2)^2+ (y1-y2)^2)
        r_left = math.sqrt(math.pow((left_face_p1[0, 0]-left_face_p2[0, 0]), 2) +
                           math.pow((left_face_p1[0, 1] - left_face_p2[0, 1]), 2))

        # 计算两个的距离作为瘦脸距离
        r_right = math.sqrt(math.pow((right_face_p1[0, 0] - right_face_p2[0, 0]), 2) +
                            math.pow((right_face_p1[0, 1] - right_face_p2[0, 1]), 2))

        # 瘦左边脸
        # origin_img, start_x, start_y, end_x, end_y, radius
        result_image = part_translate_710(image, left_face_p1[0, 0], left_face_p1[0, 1],
                                      nose_p[0, 0], nose_p[0, 1], r_left)
        # result_image = part_translate(result_image, left_face_p2[0, 0], left_face_p2[0, 1],
        #                               nose_p[0, 0], nose_p[0, 1], r_left)
        # 瘦右边脸
        result_image = part_translate_710(result_image, right_face_p1[0, 0], right_face_p1[0, 1],
                                      nose_p[0, 0], nose_p[0, 1], r_right)

        # 返回瘦脸后的图像
        return result_image


def lift_picture_710(filename, degree):

    im = cv2.imread(filename)
    # 将图像的宽度调整为600像素
    image = imutils.resize(im, width=600)

    # 读取图片为空
    if type(image) == type(None):
        print(str(filename) + "读取图片为空")

    # 获得脸部位置检测器
    detector = dlib.get_frontal_face_detector()
    # Dlib 人脸 landmark 特征点检测器
    predictor = dlib.shape_predictor('data/shape_predictor_68_face_landmarks.dat')


    result = core_face_li_710(image, detector, predictor, degree)
    cv2.imshow('result', result)
    cv2.waitKey(0)

def lift_camera_710(degree):
    # 获得脸部位置检测器
    detector = dlib.get_frontal_face_detector()
    # Dlib 人脸 landmark 特征点检测器
    predictor = dlib.shape_predictor('data/shape_predictor_68_face_landmarks.dat')

    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print('摄像头未打开')

    while True:
        # 取一帧，存在frame
        ret, frame = cap.read()

        if ret:
            result = core_face_li_710(frame, detector, predictor, degree)

        cv2.imshow('result', result)
        key = cv2.waitKey(1) & 0xFF
        if key == ord("q"):
            break

    cv2.destroyAllWindows()


if __name__ == '__main__':
    path_img = 'E:/ashijue/test_face_lift2.jpg'  #   test_face_lift.jpg
    lift_picture_710(path_img, 40)
    # lift_camera_710(70)


'''
2023年5月30日 屈雯静
对嘴唇颜色进行改变
可以对图片，视频和实时视频通过参数控制实现唇色的不同处理
参数范围：1-100
'''

import imutils
import numpy as np
import dlib
import cv2

# 对实时摄像处理
def camera_lip_710(color):
    color = 3 * color
    # 获取人脸检测器
    detector = dlib.get_frontal_face_detector()
    # 获取人脸特征点检测器
    predictor = dlib.shape_predictor('data/shape_predictor_68_face_landmarks.dat')  

    cap = cv2.VideoCapture(0)

    while True:
        ret, img = cap.read()
        # 灰度化
        img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        # 检测人脸
        rects = detector(img_gray, 0)

        # 遍历每一个检测到的人脸
        for rect in rects:
            # 获取人脸特征点
            shape = predictor(img_gray, rect)
            shape = shape.parts()
            points = [[p.x, p.y] for p in shape]

            # 将特征点转化为数组
            points = np.array(points)

            # 外嘴唇和内嘴唇的位置
            p1 = points[48:59]
            p2 = points[60:68]

            # 将嘴唇轮廓点集转化为凸包
            # 分为外轮廓和内轮廓
            hull1 = cv2.convexHull(p1)
            hull2 = cv2.convexHull(p2)

            # 生成和原图大小相同的黑色图片
            mask1 = np.zeros_like(img_gray)
            mask2 = np.zeros_like(img_gray)
            # 在黑色图片上绘制嘴唇轮廓
            cv2.fillPoly(mask1, np.array([hull1]), 255)
            cv2.fillPoly(mask2, np.array([hull2]), 255)

            # 进行按位与，得到嘴唇区域
            region1 = cv2.bitwise_and(img_gray, img_gray, mask=mask1)
            region2 = cv2.bitwise_and(img_gray, img_gray, mask=mask2)

            # 将嘴唇区域转化为三通道图像
            region1 = np.stack((region1,) * 3, axis=-1)
            region2 = np.stack((region2,) * 3, axis=-1)

            # 在生成的图片上的嘴唇区域上绘制红色嘴唇
            region1 = cv2.drawContours(region1, [hull1], -1, (0, 0, color), -1)
            region2 = cv2.drawContours(region2, [hull2], -1, (0, 0, color), -1)
            # 外嘴唇轮廓减去牙齿轮廓 就是嘴唇的轮廓
            region = region1 - region2
            # cv2.imshow("region", region)

            # 将红色嘴唇和原图进行加权叠加
            image = cv2.addWeighted(region, 0.2, img.copy(), 0.9, 0)

        cv2.imshow("result", image)
        key = cv2.waitKey(1) & 0xFF
        if key == ord("q"):
            break

# 对图片处理
def picture_lip_710(filename, color):
    color = 3 * color
    # 获取人脸检测器
    detector = dlib.get_frontal_face_detector()
    # 获取人脸特征点检测器
    predictor = dlib.shape_predictor('data/shape_predictor_68_face_landmarks.dat')

    image = cv2.imread(filename)

    # 将图像的宽度调整为600像素
    image = imutils.resize(image, width=600)
    cv2.imshow('origin', image)

    # 灰度化
    img_gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # 检测人脸
    rects = detector(img_gray, 0)

    # 遍历每一个检测到的人脸
    for rect in rects:
        # 获取人脸特征点
        shape = predictor(img_gray, rect)
        shape = shape.parts()
        points = [[p.x, p.y] for p in shape]

        # 将特征点转化为数组
        points = np.array(points)

        # 外嘴唇和内嘴唇的位置
        p1 = points[48:59]
        p2 = points[60:68]

        # 将嘴唇轮廓点集转化为凸包
        # 分为外轮廓和内轮廓
        hull1 = cv2.convexHull(p1)
        hull2 = cv2.convexHull(p2)

        # 生成和原图大小相同的黑色图片
        mask1 = np.zeros_like(img_gray)
        mask2 = np.zeros_like(img_gray)
        # 在黑色图片上绘制嘴唇轮廓
        cv2.fillPoly(mask1, np.array([hull1]), 255)
        cv2.fillPoly(mask2, np.array([hull2]), 255)

        # 进行按位与，得到嘴唇区域
        region1 = cv2.bitwise_and(img_gray, img_gray, mask=mask1)
        region2 = cv2.bitwise_and(img_gray, img_gray, mask=mask2)

        # 将嘴唇区域转化为三通道图像
        region1 = np.stack((region1,) * 3, axis=-1)
        region2 = np.stack((region2,) * 3, axis=-1)

        # 在生成的图片上的嘴唇区域上绘制红色嘴唇
        region1 = cv2.drawContours(region1, [hull1], -1, (0, 0, color), -1)
        region2 = cv2.drawContours(region2, [hull2], -1, (0, 0, color), -1)
        # 外嘴唇轮廓减去牙齿轮廓 就是嘴唇的轮廓
        region = region1 - region2
        # cv2.imshow("region", region)

        # 将红色嘴唇和原图进行加权叠加
        image = cv2.addWeighted(region, 0.2, image.copy(), 0.9, 0)

        cv2.imshow("result", image)
        cv2.waitKey(0)

# 对视频处理
def video_lip_710(filename,color):
    color = 3 * color
    # 获取人脸检测器
    detector = dlib.get_frontal_face_detector()
    # 获取人脸特征点检测器
    predictor = dlib.shape_predictor('data/shape_predictor_68_face_landmarks.dat')

    cap = cv2.VideoCapture(filename)

    while True:
        ret, img = cap.read()
        # 灰度化
        img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        # 检测人脸
        rects = detector(img_gray, 0)

        # 遍历每一个检测到的人脸
        for rect in rects:
            # 获取人脸特征点
            shape = predictor(img_gray, rect)
            shape = shape.parts()
            points = [[p.x, p.y] for p in shape]

            # 将特征点转化为数组
            points = np.array(points)

            # 外嘴唇和内嘴唇的位置
            p1 = points[48:59]
            p2 = points[60:68]

            # 将嘴唇轮廓点集转化为凸包
            # 分为外轮廓和内轮廓
            hull1 = cv2.convexHull(p1)
            hull2 = cv2.convexHull(p2)

            # 生成和原图大小相同的黑色图片
            mask1 = np.zeros_like(img_gray)
            mask2 = np.zeros_like(img_gray)
            # 在黑色图片上绘制嘴唇轮廓
            cv2.fillPoly(mask1, np.array([hull1]), 255)
            cv2.fillPoly(mask2, np.array([hull2]), 255)

            # 进行按位与，得到嘴唇区域
            region1 = cv2.bitwise_and(img_gray, img_gray, mask=mask1)
            region2 = cv2.bitwise_and(img_gray, img_gray, mask=mask2)

            # 将嘴唇区域转化为三通道图像
            region1 = np.stack((region1,) * 3, axis=-1)
            region2 = np.stack((region2,) * 3, axis=-1)

            # 在生成的图片上的嘴唇区域上绘制红色嘴唇
            region1 = cv2.drawContours(region1, [hull1], -1, (0, 0, color), -1)
            region2 = cv2.drawContours(region2, [hull2], -1, (0, 0, color), -1)
            # 外嘴唇轮廓减去牙齿轮廓 就是嘴唇的轮廓
            region = region1 - region2
            # cv2.imshow("region", region)

            # 将红色嘴唇和原图进行加权叠加
            image = cv2.addWeighted(region, 0.2, img.copy(), 0.9, 0)

        cv2.imshow("result", image)
        key = cv2.waitKey(1) & 0xFF
        if key == ord("q"):
            break

if __name__ == '__main__':
    # camera_lip_710(50)
    # picture_lip_710('E:/ashijue/test_face_lift2.jpg', 50)
    video_lip_710('E:/ashijue/result1_4_1.mp4', 50)
import sys

import qtawesome
from PyQt5.QtCore import QSize
from PyQt5.QtGui import QPainter, QPixmap

from MainWindow203 import *
from PictureWindow203 import *


class myMainWindow(QtWidgets.QMainWindow, Ui_MainWindow):
    def __init__(self, parent=None):
        super(myMainWindow, self).__init__(parent)
        self.picture_window = None  # 人像美容的窗口信号

        # 美化主窗口
        self.setupUi(self)
        self.resize(900, 850)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.setIconSize(QSize(40, 40))
        window_icon = qtawesome.icon('fa5b.optin-monster', color='pink')  # 添加窗口图标
        self.setWindowIcon(window_icon)
        camera_icon = qtawesome.icon('fa5s.camera', color='pink')  # 添加相机图标
        self.pushButton_3.setIcon(camera_icon)
        self.pushButton_3.setIconSize(QSize(60, 60))
        picture_icon = qtawesome.icon('mdi.face-woman-shimmer', color='pink')  # 添加人像美容图标
        self.pushButton.setIcon(picture_icon)
        self.pushButton.setIconSize(QSize(60, 60))
        video_icon = qtawesome.icon('mdi.video-vintage', color='pink')  # 添加视频美容图标
        self.pushButton_2.setIcon(video_icon)
        self.pushButton_2.setIconSize(QSize(60, 60))
        help_icon = qtawesome.icon('fa5s.question', color='yellow')  # 添加帮助图标
        self.actionbanzhu.setIcon(help_icon)
        delete_icon = qtawesome.icon('ri.delete-bin-line', color='white')  # 添加删除图标
        self.actionshanchu.setIcon(delete_icon)
        save_icon = qtawesome.icon('ri.save-3-line', color='white')  # 添加保存图标
        self.actionbaocun.setIcon(save_icon)

        # 关联触发事件
        self.pushButton.clicked.connect(self.picture_win)  # 打开人像美容界面

    # 添加背景图片
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.drawRect(self.rect())
        painter.setOpacity(0.9)
        pixmap = QPixmap("./background2.jpg")  # 换成自己的图片的相对路径
        painter.drawPixmap(self.rect(), pixmap)

    # 打开人像美容界面
    def picture_win(self):
        self.hide()
        self.picture_window = myPictureWindow()
        self.picture_window.show()


# 人像美容界面
class myPictureWindow(QtWidgets.QMainWindow, PictureWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setupUi(self)
        # 人像美容界面美化
        self.resize(900, 850)
        self.setAttribute(QtCore.Qt.WA_TranslucentBackground)
        self.setIconSize(QSize(40, 40))
        win_icon = qtawesome.icon('fa5b.optin-monster', color='pink')  # 设置窗口图标
        self.setWindowIcon(win_icon)
        open_icon = qtawesome.icon('ri.folder-open-line', color='lightblue')  # 设置打开图标
        self.actionopen.setIcon(open_icon)
        delete_icon = qtawesome.icon('ri.delete-bin-line', color='lightblue')  # 设置删除图标
        self.actiondelete.setIcon(delete_icon)
        save_icon = qtawesome.icon('ri.save-3-line', color='lightblue')  # 设置保存图标
        self.actionsave.setIcon(save_icon)
        mopi_icon = qtawesome.icon('ph.circle-half-bold', color='white')  # 设置磨皮图标
        self.mopi_pushButton.setIcon(mopi_icon)
        self.mopi_pushButton.setIconSize(QSize(40,40))
        meibai_icon = qtawesome.icon('mdi6.face-woman-shimmer-outline', color='white')  # 设置美白图标
        self.meibai_pushButton.setIcon(meibai_icon)
        self.meibai_pushButton.setIconSize(QSize(40,40))
        shoulian_icon = qtawesome.icon('ph.person-thin', color='white')  # 设置瘦脸图标
        self.shoulian_pushButton.setIcon(shoulian_icon)
        self.shoulian_pushButton.setIconSize(QSize(40,40))
        mouth_icon = qtawesome.icon('mdi6.lipstick', color='white')  # 设置红唇图标
        self.mouth_pushButton.setIcon(mouth_icon)
        self.mouth_pushButton.setIconSize(QSize(40,40))
        eye_icon = qtawesome.icon('ph.eye', color='white')  # 设置眼睛图标
        self.eye_pushButton.setIcon(eye_icon)
        self.eye_pushButton.setIconSize(QSize(40,40))
        meimao_icon = qtawesome.icon('ph.eye-closed-bold', color='white')  # 设置眉毛图标
        self.meimao_pushButton.setIcon(meimao_icon)
        self.meimao_pushButton.setIconSize(QSize(40,40))


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    MainPageWindow = myMainWindow()
    MainPageWindow.show()
    sys.exit(app.exec_())
